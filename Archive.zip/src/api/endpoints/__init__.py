"""Endpoints package initialization."""

