"""Dashboard pages package."""

